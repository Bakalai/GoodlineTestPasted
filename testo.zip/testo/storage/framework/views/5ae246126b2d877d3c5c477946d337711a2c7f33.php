<?php $__env->startSection('page_title'); ?> Главная страница <?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
    <h1>Главная страница</h1>
    <p> Этот сайт содержит в себе решение тестового задания бэкэнд(базовый)</p>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\egord\PhpstormProjects\Testo\testo\resources\views/home.blade.php ENDPATH**/ ?>