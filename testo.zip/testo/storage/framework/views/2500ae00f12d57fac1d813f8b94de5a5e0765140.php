<?php $__env->startSection('page_title'); ?> Личный кабинет <?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
    <h1>Личный кабинет</h1>
    <p> Тут отображены только ваши "пасты"</p>

    <?php
        use App\Models\pasted;
        use Carbon\Carbon;
            $publicates = new pasted();
            $publicates = $publicates->all();

    ?>
    <br>
    <h1>Ваши  записи </h1>
    <?php $__currentLoopData = $publicates->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                                             
    <?php
        $deda = $el -> created_at->addSeconds($el -> lifetime) ;                                                        //deda - время конца жизни публикации
        $timenow = Carbon::now();
        $immortalnost = $el -> lifetime == 3;
        $showornot = $timenow < $deda ;                                                                                  // Весь вывод зависит от переменной showornot, expiration time проверк
    ?>

    <?php if(  ($showornot or $immortalnost) and (Auth::check() and $el-> authorId == Auth::user()->id)): ?>             <!-- счет до 10 тут же, Если доступ не только по ссылке или (пользователь и авторизован и совпадает с автором)-->
    <div class="alert alert-info">
        <h3><?php echo e($el -> subject); ?></h3>
        <?php if($el -> anon == 1): ?>
            <b>Аноним</b>
        <?php else: ?>
            <b> <?php echo e(DB::table('users')->whereIn('id', array($el -> authorId))->get("name")[0] -> name); ?>    </b>         <!-- Если анонимная запись, то скрываем, иначе вывод name пользоватея по id -->

        <?php endif; ?>

        <p><?php echo e($el -> message); ?></p>
        <h6><?php echo e($el -> created_at); ?></h6>
        <a href="<?php echo e($el -> hash); ?>"><?php echo e($_SERVER['HTTP_HOST']."/" .$el -> hash); ?></a>

    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\egord\PhpstormProjects\Testo\testo\resources\views/lk.blade.php ENDPATH**/ ?>