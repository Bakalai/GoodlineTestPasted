@extends('layout')
@section('page_title') Главная страница @endsection
@section('main_content')
    <h1>Главная страница</h1>
    <p> Этот сайт содержит в себе решение тестового задания бэкэнд(базовый)</p>



@endsection
